cwRsync 6.2.1 - Rsync client for Windows
July 2020, provided by itefix.net - https://www.itefix.net/cwrsync

This archive contains a barebone distribution of Rsync for Windows.

Unzip archive contents to a directory, update the supplied batch file
cwrsync.cmd. That's all you need to be able to initiate rsync connectionsfrom
from a command line.

NB! In the case you run into -meaningless- permission issues, please
consult our FAQ
https://www.itefix.net/content/permissions-filesdirectories-are-clutteredmixed

cwRsync FAQs can also be helpful - https://itefix.net/cwrsync-faqs

We provide a paid version of cwRsync if you want to setup an Rsync server.
See https://www.itefix.net/cwrsync for more information.

ENJOY RSYNC!!

Version information:
Rsync 3.2.3
Cygwin 3.1.7
OpenSSH 8.4p
LibreSSL 3.2.3

Output of 'rsync --version':
----------------------------
rsync  version 3.2.2  protocol version 31
Copyright (C) 1996-2020 by Andrew Tridgell, Wayne Davison, and others.
Web site: https://rsync.samba.org/
Capabilities:
    64-bit files, 64-bit inums, 64-bit timestamps, 64-bit long ints,
    socketpairs, hardlinks, symlinks, IPv6, atimes, batchfiles, inplace,
    append, no ACLs, no xattrs, optional protect-args, iconv, symtimes,
    prealloc
Optimizations:
    no SIMD, asm, openssl-crypto
Checksum list:
    xxh64 (xxhash) md5 md4 none
Compress list:
    zstd lz4 zlibx zlib none

rsync comes with ABSOLUTELY NO WARRANTY.  This is free software, and you
are welcome to redistribute it under certain conditions.  See the GNU
General Public Licence for details.

Output of 'ssh -V':
-------------------
OpenSSH_8.4p1, LibreSSL 3.2.3